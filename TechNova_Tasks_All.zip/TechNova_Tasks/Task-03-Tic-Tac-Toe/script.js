const board=document.getElementById("board"),statusEl=document.getElementById("status");
const restart=document.getElementById("restart");
let cells,turn="X",gameOver=false;
const wins=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];

function create(){
 board.innerHTML="";turn="X";gameOver=false;statusEl.textContent="Player X's turn";
 for(let i=0;i<9;i++){
  const b=document.createElement("button");b.className="cell";b.dataset.index=i;
  b.onclick=()=>move(i);board.appendChild(b);
 }
 cells=[...document.querySelectorAll(".cell")];
}
function move(i){
 if(gameOver||cells[i].textContent)return;
 cells[i].textContent=turn;
 const win=wins.find(combo=>combo.every(n=>cells[n].textContent===turn));
 if(win){gameOver=true;win.forEach(n=>cells[n].classList.add("win"));statusEl.textContent=`Player ${turn} wins!`;return}
 if(cells.every(c=>c.textContent)){gameOver=true;statusEl.textContent="It's a draw!";return}
 turn=turn==="X"?"O":"X";statusEl.textContent=`Player ${turn}'s turn`;
}
restart.onclick=create;create();