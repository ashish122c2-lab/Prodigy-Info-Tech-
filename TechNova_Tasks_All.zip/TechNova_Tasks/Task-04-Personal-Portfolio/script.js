const menuBtn=document.getElementById("menuBtn"),nav=document.getElementById("nav");
menuBtn.onclick=()=>nav.classList.toggle("active");
document.querySelectorAll("#nav a").forEach(a=>a.onclick=()=>nav.classList.remove("active"));