let startTime=0,elapsed=0,timer=null;
const display=document.getElementById("display");
const laps=document.getElementById("laps");

function format(ms){
  const cs=Math.floor((ms%1000)/10);
  const total=Math.floor(ms/1000);
  const s=total%60;
  const m=Math.floor(total/60)%60;
  const h=Math.floor(total/3600);
  return [h,m,s].map(n=>String(n).padStart(2,"0")).join(":")+"."+String(cs).padStart(2,"0");
}
function update(){elapsed=Date.now()-startTime;display.textContent=format(elapsed)}
document.getElementById("start").onclick=()=>{
  if(timer)return;
  startTime=Date.now()-elapsed;
  timer=setInterval(update,10);
};
document.getElementById("pause").onclick=()=>{
  if(!timer)return;
  clearInterval(timer);timer=null;update();
};
document.getElementById("reset").onclick=()=>{
  clearInterval(timer);timer=null;elapsed=0;display.textContent="00:00:00.00";laps.innerHTML="";
};
document.getElementById("lap").onclick=()=>{
  if(!timer)return;
  const li=document.createElement("li");
  li.textContent=`Lap ${laps.children.length+1} — ${format(elapsed)}`;
  laps.prepend(li);
};