const cityInput=document.getElementById("city"),searchBtn=document.getElementById("searchBtn"),locationBtn=document.getElementById("locationBtn"),message=document.getElementById("message"),result=document.getElementById("result");
const place=document.getElementById("place"),temperature=document.getElementById("temperature"),condition=document.getElementById("condition"),feels=document.getElementById("feels"),humidity=document.getElementById("humidity"),wind=document.getElementById("wind");

const weatherText={0:"Clear sky",1:"Mainly clear",2:"Partly cloudy",3:"Overcast",45:"Fog",48:"Rime fog",51:"Light drizzle",53:"Moderate drizzle",55:"Dense drizzle",61:"Light rain",63:"Moderate rain",65:"Heavy rain",71:"Light snow",73:"Moderate snow",75:"Heavy snow",80:"Rain showers",81:"Rain showers",82:"Heavy rain showers",95:"Thunderstorm"};

async function getWeather(lat,lon,name){
  message.textContent="Loading weather...";
  result.classList.add("hidden");
  try{
    const url=`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&timezone=auto`;
    const res=await fetch(url); if(!res.ok) throw new Error();
    const data=await res.json(), c=data.current;
    place.textContent=name;
    temperature.textContent=Math.round(c.temperature_2m);
    feels.textContent=Math.round(c.apparent_temperature);
    humidity.textContent=c.relative_humidity_2m;
    wind.textContent=Math.round(c.wind_speed_10m);
    condition.textContent=weatherText[c.weather_code]||"Current conditions";
    message.textContent="";
    result.classList.remove("hidden");
  }catch(e){message.textContent="Unable to load weather. Please try again."}
}
async function searchCity(){
  const city=cityInput.value.trim(); if(!city)return;
  message.textContent="Finding city...";
  try{
    const res=await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`);
    const data=await res.json(); if(!data.results?.length)throw new Error();
    const p=data.results[0];
    getWeather(p.latitude,p.longitude,[p.name,p.country].filter(Boolean).join(", "));
  }catch(e){message.textContent="City not found."}
}
searchBtn.onclick=searchCity;
cityInput.addEventListener("keydown",e=>{if(e.key==="Enter")searchCity()});
locationBtn.onclick=()=>{
  if(!navigator.geolocation){message.textContent="Geolocation is not supported by your browser.";return}
  message.textContent="Getting your location...";
  navigator.geolocation.getCurrentPosition(
    p=>getWeather(p.coords.latitude,p.coords.longitude,"Your Location"),
    ()=>message.textContent="Location permission was not granted."
  );
};